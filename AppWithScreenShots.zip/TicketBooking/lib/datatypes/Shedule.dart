class Shedule {
  String record;
  String dtime;
  String atime;
  String from;
  String to;
  String plane;

  Shedule ({this.record, this.dtime, this.atime, this.from, this.to, this.plane});
}