//
//  Generated file. Do not edit.
//

#include "generated_plugin_registrant.h"


void fl_register_plugins(FlPluginRegistry* registry) {
}
